# Pinned TP-Link override

- Base: Home Assistant core 2026.11.3 components/tplink (copied from the 2026.11.3 image)
- Library: python-kasa PR #1592, commit f4dff399016a9daa47316ffb209f6b74a989b6dc (kasa/ folder only, in _vendor/)
- Extra deps bundled in _vendor/: ecdsa 0.19.2, six 1.17.0
- Nothing is installed or downloaded at HA startup

Remove: delete this folder (custom_components/tplink) and restart Home Assistant.
Re-check before every HA update: the core tplink integration changes and this copy shadows it.
